from django.contrib import admin
from .models import ITC_Member
admin.site.register(ITC_Member)

# Register your models here.


