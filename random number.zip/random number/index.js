function goDoSomething(gamer_number){
    var s =gamer_number.value;
    var random= Math.random()*100;
    console.log(random,s);
    
    if (random==s)
    document.getElementById("result").innerHTML ="you are smart as the robot"
    else if (random > s)
    document.getElementById("result").innerHTML ="OPPSS,IT'S TRUE THE ROBOT IS SMARTER THAN HUMENS"
    else  
    document.getElementById("result").innerHTML ="ALLEZ YOU WIN,YOU GEUSSED A HIGHTER NUMBER"

}